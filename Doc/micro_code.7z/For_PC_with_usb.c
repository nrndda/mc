#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#define F_CPU 16000000UL  // 16 MHz

	unsigned char min=0,sec=0,hour=0;
	unsigned int t=0;
	unsigned char B0Pressed,B1Pressed,B2Pressed;
	unsigned int bin_time;
	SIGNAL (SIG_OVERFLOW0)
	{
		t+=1;
		if (t >= 61)
		{
			sec+=1;
			t=0;
		}
		if (sec >= 60) 
		{
			min+=1;
			sec=0;
		}
		if (min >= 60)
		{
			hour+=1;
			min=0;
		}
		if (hour >= 24)
		{
			hour = 0;
		}
	}

   int main(void)              // начало основой программы
   {
   	DDRC = 0xff;	// Зелёный
   	DDRA = 0xff;	// Общий анод
	DDRD = 0xff;	// Красный
	PORTA = 0;
	PORTD = 0;
	PORTC = 0;
	TCCR0 = 0b00000101;
	TCNT0 = 0x00;		//Timer0 start point
	TIMSK = 0b00000010;	//Timer0 on
	MCUCR= (1 << SE);	// Idle mode. Timer/Counter on	
	SREG = (1 << 7);
	unsigned int temp=0;
	PORTA = 0xff;
	_delay_ms(30);
    while (1)             // Бесконечный цикл
	{
		bin_time=sec + (min + hour*60)*60;
		if (bin_time<256)
		{ 
			PORTC = !bin_time;
			PORTD = 0xff;
			_delay_ms(50);
		}
		else
		{
			PORTC = !bin_time;
			PORTD = 0xff;
			temp = ((bin_time-PORTC)>>8);
			_delay_ms(25);
			PORTD = !bin_time;
			PORTC = 0xff;
			_delay_ms(25);
		}
		sec++;
/*		if (B0Pressed == 1) //Если произошло нажатие на кнопку, 
		{
			min=0;sec=0;hour=0;
			B0Pressed = 0;
			while ((PINE & (1 << PC0)) == 0)
      		{}
    	}
    	else
    	{
      		if ((PINE & (1 << PC0)) == 0)      //Фиксирует нажатие
      		{
        		_delay_ms(5);        //Устранение "дребезга клавиш"
		        if ((PINE & (1 << PC0)) == 0)    //Проверяет нажатие
        		{
          			B0Pressed = 1;  //Устанавливает флаг "кнопка нажата"
        		}
      		}
   		}*/
	}
		return 0;
   }

