/*
** LCD.C - Example program to demonstrate use of LCD_4X20.C
**
** Copyright 1996 by Randy Rasa
**                   rrasa@sky.net
**                   http://www.sky.net/~rrasa
**
** Version 1.00, 05-17-96
**
** These routines may be used in any way you see fit ... no strings attached.
*/


#include <conio.h>
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include "lcd_4x20.h"


void DisplayScreen (char *ptr);
void DisplayScreenWipeOld (char *ptr);

/*
** main() -- program starts here ...
*/
void main (void) {
	char done = 0;

	printf("\n\nLCD_4X20 Demonstration Program, v1.00\n\n");

	// initialize the LCD module
	printf ("Initializing LCD ...");
	LCD_Init();

	// display a simple menu, which is used to demonstrate
	// the operation of the LCD module
	while (!done) {
		LCD_Clear();
		LCD_DisplayStringCentered (2, "Ready");
		printf("\n\n");
		printf("1. Sample Title Screen\n");
		printf("2. Sample Multi-Page Screen\n");
		printf("3. Sample Menu\n");
		printf("4. Sample Marquee\n");
		printf("5. Sample Flashing\n");
		printf("5. Sample Bar Graph\n");
		printf("Esc = Exit\n");

		switch (getch()) {

			//
			// display sample title screen (with "wipe" effects)
			//
			case '1':
				{
					char screen[] = "     LCD_4X20.C     "
													"   Demonstration    "
													"      Program       "
													"    Version 1.00    ";
					LCD_DisplayScreen(screen);
					delay(2000);
				}
				{
					char screen[] = " Copyright 1996 By  "
													"     Randy Rasa     "
													"                    "
													"       Enjoy!       ";
					LCD_WipeOffLR();
					LCD_WipeOnRL(screen);
					delay(2000);
				}
				break;

			//
			// display sample mult-page screen (with "arrows")
			//
			case '2':
				{
					char screen1[] = "This is a sample    "
													 "multi-page screen.  "
													 "Note the arrow in   "
													 "the corners, which \1";
					char screen2[] = "indicate that there\0"
													 "is more text avail- "
													 "able to be viewed,  "
													 "by pressing the    \1";
					char screen3[] = "arrow keys.  The   \0"
													 "arrows only show up "
													 "when more screens   "
													 "can be accessed.   \1";
					char screen4[] = "When the last and/ \0"
													 "or first screen is  "
													 "reached, the arrow  "
													 "disappears.         ";
					char screen = 1;
					char exit = 0;
					printf(" '+' = Up Arrow, '-' = Down Arrow, or Esc ...\n");
					while (!exit) {
						switch (screen) {
							case 1: LCD_DisplayScreen(screen1); break;
							case 2: LCD_DisplayScreen(screen2); break;
							case 3: LCD_DisplayScreen(screen3); break;
							case 4: LCD_DisplayScreen(screen4); break;
						}
						switch (getch()) {
							case 27:
								exit = 1;
								break;
							case 0:
								switch (getch()) {
									case 0x50:
										screen++;
										if (screen>4) screen = 4;
										break;
									case 0x48:
										screen--;
										if (screen<1) screen = 1;
										break;
								}
								break;
							default:
								printf("code: %x\n", getch());
						}
					}
				}
				break;

			//
			// display sample menu system
			//
			case '3':
				{
					char screen1[] = "---- MAIN MENU -----"
													 "~Option Number 1    "
													 " Option Number 2    "
													 " Option Number 3   \1";
					char screen2[] = "---- MAIN MENU -----"
													 " Option Number 1    "
													 "~Option Number 2    "
													 " Option Number 3   \1";
					char screen3[] = "---- MAIN MENU -----"
													 " Option Number 1    "
													 " Option Number 2    "
													 "~Option Number 3   \1";
					char screen4[] = "---- MAIN MENU -----"
													 " Option Number 2   \0"
													 " Option Number 3    "
													 "~Option Number 4   \1";
					char screen5[] = "---- MAIN MENU -----"
													 " Option Number 3   \0"
													 " Option Number 4    "
													 "~Option Number 5    ";
					char screen = 1;
					char exit = 0;
					printf(" '+' = Up Arrow, '-' = Down Arrow, or Esc ...\n");
					LCD_CursorOn();
					while (!exit) {
						switch (screen) {
							case 1: LCD_DisplayScreen(screen1); LCD_Cursor(2,1); break;
							case 2: LCD_DisplayScreen(screen2); LCD_Cursor(3,1); break;
							case 3: LCD_DisplayScreen(screen3); LCD_Cursor(4,1); break;
							case 4: LCD_DisplayScreen(screen4); LCD_Cursor(4,1); break;
							case 5: LCD_DisplayScreen(screen5); LCD_Cursor(4,1); break;
						}
						switch (getch()) {
							case 27:
								exit = 1;
								break;
							case 0:
								switch (getch()) {
									case 0x50:
										screen++;
										if (screen>5) screen = 5;
										break;
									case 0x48:
										screen--;
										if (screen<1) screen = 1;
										break;
								}
								break;
							default:
								printf("code: %x\n", getch());
						}
					}
					LCD_CursorOff();
				}
				break;

			//
			// display sample "marquee"
			//
			case '4':
				{
					char screen[] = "                    "
													"The top line of this"
													"screen should be    "
													"scrolling away ...  ";
					char longline[] = "                    This is a very long line of text, scrolling across the screen like a marquee.                    ";
					char i = 0;
					LCD_DisplayScreen(screen);
					printf("Press any key to stop ...\n");
					while (!kbhit()) {
						LCD_DisplayRow(1, longline + i++);
						if (i > (strlen(longline)-20)) i = 0;
						delay(250);
					}
					getch();
				}
				break;

			//
			// display sample "flashing"
			//
			case '5':
				{
					char screen1[] = "Use flashing text   "
													 "to attract attention"
													 "to a word or phrase."
													 " Different Flashing ";
					char screen2[] = "Use          text   "
													 "to attract attention"
													 "to a word or phrase."
													 "\377\377\377\377\377"
													 "\377\377\377\377\377"
													 "\377\377\377\377\377"
													 "\377\377\377\377\377";
					while (!kbhit()) {
						LCD_DisplayScreen(screen1);
						delay(250);
						LCD_DisplayScreen(screen2);
						delay(250);
					}
					getch();
				}
				break;

			//
			// display sample "bar graph"
			//
			case '6':
				{
					char screen[]  = "  Sample Bar Graph  "
													 "                    "
													 "                    "
													 "LO                HI";
					char bars[6] = { ' ', 0x04, 0x05, 0x06, 0x07, 0xff };
					LCD_DisplayScreen(screen);
					printf("Press any key to stop ...\n");
					while (!kbhit()) {
						char i, j;
						for (i=1; i<21; i++) {							// ramp up
							for (j=1; j<6; j++) {
								LCD_Cursor(3,i);
								LCD_DisplayCharacter(bars[j]);
								delay(10);
							}
						}
						for (i=20; i>=1; i--) {             // ramp down
							for (j=5; j>=1; j--) {
								LCD_Cursor(3,i);
								LCD_DisplayCharacter(bars[j-1]);
								delay(10);
							}
						}
					}
					getch();
				}
				break;

			//
			// display "bye" message and exit
			//
			case 27:
				LCD_Clear();
				LCD_DisplayStringCentered (1, "Bye Now!");
				LCD_DisplayStringCentered (3, "Ya'll Come Back Now, Hear?");
				LCD_DisplayStringCentered (4, "Hear?");
				done = 1;
				break;
		}

	}

}



