
/* How to control a HD44780-based Character-LCD
 *
 * Chip:                    ATMEL AT90S2313-10PI
 * Clock:                   9.420 MHz
 * Compiler:                avr-gcc
 *
 * ATMEL PIN                LCD PIN
 *
 * PD0(2)                   RS(4)
 * PD1(3)                   R/W(5)
 * PD6(11)                  E(6)
 *
 * PB0(12)                  D0(7)
 * PB1(13)                  D1(8)
 * PB2(14)                  D2(9)
 * PB3(15)                  D3(10)
 * PB4(16)                  D4(11)
 * PB5(17)                  D5(12)
 * PB6(18)                  D6(13)
 * PB7(19)                  D7(14)
 *
 * Written by:              Jon Wackley (VE3JTN)
 * Date:                    November 3rd 2002
 *
 */

#include <io.h>

#define FALSE               0
#define TRUE                1

#define DDR_PORT_INPUT      ( 0 )
#define DDR_PORT_OUTPUT     ( 0xff )
#define IN_PORT_TRIS        ( 0 )
#define IN_PORT_PULL        ( 0xff )

#define LCD_CTRL_PORT       ( PORTD )
#define LCD_CTRL_DDR        ( DDRD )

#define LCD_RS_BIT          ( PD0 )
#define LCD_RS_MASK         ( 0x01 << LCD_RS_BIT )
#define LCD_RW_BIT          ( PD1 )
#define LCD_RW_MASK         ( 0x01 << LCD_RW_BIT )
#define LCD_E_BIT           ( PD6 )
#define LCD_E_MASK          ( 0x01 << LCD_E_BIT )
#define LCD_CTRL_MASK       ( LCD_RS_MASK | LCD_RW_MASK | LCD_E_MASK )
#define LCD_CTRL_OUTPUT     ( LCD_CTRL_MASK & DDR_PORT_OUTPUT )

#define LCD_DATA_PORT       ( PORTB )
#define LCD_DATA_DDR        ( DDRB )
#define LCD_DATA_INPUT      ( DDR_PORT_INPUT )
#define LCD_DATA_OUTPUT     ( DDR_PORT_OUTPUT )
#define LCD_BUSY_BIT        ( PB7 )
#define LCD_BUSY_MASK       ( 0x01 << LCD_BUSY_BIT )
#define LCD_READ_DELAY      ( 3U )

#define CHARS_PER_LINE      ( 8U )
#define CALIBRATED_DELAY    ( 690U )
#define STARTUP_DELAY       ( 30U )

#define lcd_put_command( command ) lcd_put( command, TRUE )
#define lcd_put_char( character ) lcd_put( character, FALSE )


typedef uint8_t BOOL;
typedef uint8_t PORT;
typedef uint8_t PORT_VALUE;


void
delay ( uint16_t delay ) {

    uint16_t counter = 0;

    for ( ; counter < delay; counter++ );

}


void
delay_factor ( uint16_t delay_factor ) {

    while ( delay_factor-- != 0 ) {
        delay( CALIBRATED_DELAY );
    }

}


void
configure_port ( PORT port, PORT_VALUE port_value, PORT_VALUE ddr_value ) {

    PORT ddr = LCD_DATA_DDR;

    if ( port == LCD_CTRL_PORT ) {
        ddr = LCD_CTRL_DDR;
    }

    __mmio( ddr ) = DDR_PORT_INPUT;
    __mmio( port ) = IN_PORT_TRIS;
    __mmio( ddr ) = ddr_value;
    __mmio( port ) = port_value;

}


void
lcd_busy ( void ) {

    configure_port( LCD_DATA_PORT, IN_PORT_TRIS, DDR_PORT_INPUT );

    cbi( LCD_CTRL_PORT, LCD_RS_BIT );
    sbi( LCD_CTRL_PORT, LCD_RW_BIT );
    sbi( LCD_CTRL_PORT, LCD_E_BIT );
    delay( LCD_READ_DELAY );            /* takes 1 to 2 micro seconds for busy to assert*/

    loop_until_bit_is_clear( PINB, LCD_BUSY_BIT );
    cbi( LCD_CTRL_PORT, LCD_E_BIT );
    cbi( LCD_CTRL_PORT, LCD_RW_BIT );

    configure_port( LCD_DATA_PORT, 0, DDR_PORT_OUTPUT );

}


/* lcd_put
 *
 * Purpose:     - Writes characters or commands to LCD.
 *              - Used with lcd_put_command and lcd_put_char macros
 *              - BOOL command indicates whether char or command is output
 *              - value is output to LCD
 *
 */

enum LCD_CMDS {
    LCD_CMDS_NONE,
    LCD_CMDS_CLEAR,
    LCD_CMDS_HOME = LCD_CMDS_CLEAR << 1,
    LCD_CMDS_ENTRY_MODE = LCD_CMDS_HOME << 1,
    LCD_CMDS_DISPLAY_MODE = LCD_CMDS_ENTRY_MODE << 1,
    LCD_CMDS_CURSOR_DISP = LCD_CMDS_DISPLAY_MODE << 1,
    LCD_CMDS_CONFIGURE = LCD_CMDS_CURSOR_DISP << 1,
    LCD_CMDS_SET_CGRAM = LCD_CMDS_CONFIGURE << 1,
    LCD_CMDS_SET_DRAM = LCD_CMDS_SET_CGRAM << 1
};

void
lcd_put ( uint8_t value, BOOL command ) {

    lcd_busy( );
    cbi( LCD_CTRL_PORT, LCD_RW_BIT );
    if ( command ) {
        cbi( LCD_CTRL_PORT, LCD_RS_BIT );
    } else {
        sbi( LCD_CTRL_PORT, LCD_RS_BIT );
    }
    sbi( LCD_CTRL_PORT, LCD_E_BIT );
    outp( value, LCD_DATA_PORT );
    cbi( LCD_CTRL_PORT, LCD_E_BIT );

}


/* lcd_clear
 *
 * Purpose:     - Clears display and returns cursor to home position (upper-left).
 *
 */

void
lcd_clear ( void ) {
    lcd_put_command( LCD_CMDS_CLEAR );
}


/* lcd_home
 *
 * Purpose:     - Returns cursor to home position.
 *              - Returns display to original position (when shifted).
 *
 */

void
lcd_home ( void ) {
    lcd_put_command( LCD_CMDS_HOME );
}


/* lcd_entry_mode
 *
 * Purpose:     - Sets entry mode of the LCD
 *              - Required entry mode must be set
 *
 * b0    : 0 = no display shift, 1 = display shift
 * b1    : 0 = auto-decrement, 1 = auto-increment
 * b2-b7 : don't care
 *
 */

enum EM_ARGS {
    EM_ARGS_NONE,
    EM_ARGS_DISPLAY_SHIFT,
    EM_ARGS_AUTO_INCREMENT = EM_ARGS_DISPLAY_SHIFT << 1
};

void
lcd_entry_mode ( uint8_t entry_mode ) {
    lcd_put_command( ( entry_mode & ( LCD_CMDS_ENTRY_MODE - 1 ) ) | LCD_CMDS_ENTRY_MODE );
}


/* lcd_display_mode
 *
 * Purpose:     - Sets display control
 *              - Required display mode must be set
 *
 * b0    : 0 = cursor blink off, 1 = cursor blink on (if b1 = 1)
 * b1    : 0 = cursor off,  1 = cursor on
 * b2    : 0 = display off, 1 = display on (display data remains in DD-RAM)
 * b3-b7 : don't care
 *
 */

enum DM_ARGS {
    DM_ARGS_NONE,
    DM_ARGS_CURSOR_BLINK,
    DM_ARGS_CURSOR_ON = DM_ARGS_CURSOR_BLINK << 1,
    DM_ARGS_DISPLAY_ON = DM_ARGS_CURSOR_ON << 1
};

void
lcd_display_mode ( uint8_t display_mode ) {
    lcd_put_command( ( display_mode & ( LCD_CMDS_DISPLAY_MODE - 1 ) ) | LCD_CMDS_DISPLAY_MODE );
}


/*
 * lcd_cursor_display_mode
 *
 * Purpose:     - Sets cursor-move or display-shift (S/C), shift direction (R/L).
 *              - DDRAM contents remains unchanged.
 */

enum CUR_DISP_ARGS {
    CUR_DISP_ARGS_NONE,
    CUR_DISP_ARGS_RIGHT = 0x04,
    CUR_DISP_ARGS_SHIFT = CUR_DISP_ARGS_RIGHT << 1
};

void
lcd_cursor_display_mode ( uint8_t cursor_mode ) {
    lcd_put_command( ( cursor_mode & ( LCD_CMDS_CURSOR_DISP - 1 ) ) | LCD_CMDS_CURSOR_DISP );
}


/* lcd_configure ( function set )
 *
 * Purpose - Sets interface data length (DL), number of display line (N) and character font(F).
 *
 */

enum CONFIG_ARGS {
    CONFIG_ARGS_NONE,
    CONFIG_ARGS_5X10_FONT = 0x04,
    CONFIG_ARGS_MULTI_LINE = CONFIG_ARGS_5X10_FONT << 1,
    CONFIG_ARGS_8_BIT = CONFIG_ARGS_MULTI_LINE << 1
};

void
lcd_configure ( uint8_t configuration ) {
    lcd_put_command( ( configuration & ( LCD_CMDS_CONFIGURE - 1 ) ) | LCD_CMDS_CONFIGURE );
}


/*
 * Purpose:     - Sets the Character-Generator-RAM address.
 *                      CGRAM data is read/written after this setting.
 *              - Required CGRAM address must be set
 *
 * b0-5 : required CGRAM address
 * b6-7 : don't care
 *
 */

void
lcd_set_char_gen_addr ( uint8_t address ) {
    lcd_put_command( ( address & ( LCD_CMDS_SET_CGRAM - 1 ) ) | LCD_CMDS_SET_CGRAM );
}


/* lcd_set_display_address
 *
 * Purpose:     - Sets the Display-Data-RAM address.
 *                      DDRAM data is read/written after this setting.
 *              - Required entry mode must be set
 *
 * b0-6 : required DDRAM address
 * b7           : don't care
 */

enum DA_ARGS {
    DA_ARGS_LINE1,
    DA_ARGS_LINE2 = 0x40
};

void
lcd_set_display_address ( uint8_t address ) {
    lcd_put_command( address | LCD_CMDS_SET_DRAM );
}


/* lcd_get_address_counter
 *
 * Purpose:     - Returns address counter contents, used for both DDRAM and CGRAM.
 *              - RAM address is returned
 *
 * N.B. not yet tested
 *
 */

uint8_t
lcd_get_address_counter ( void ) {

    uint8_t address_counter = 0;

    configure_port( LCD_DATA_PORT, IN_PORT_TRIS, LCD_DATA_INPUT );

    cbi( LCD_CTRL_PORT, LCD_RS_BIT );
    sbi( LCD_CTRL_PORT, LCD_RW_BIT );
    sbi( LCD_CTRL_PORT, LCD_E_BIT );
    delay( LCD_READ_DELAY );
    address_counter = PINB & ~LCD_BUSY_MASK;
    cbi( LCD_CTRL_PORT, LCD_E_BIT );

    configure_port( LCD_DATA_PORT, 0, LCD_DATA_OUTPUT );

    return address_counter;

}


void
lcd_init ( void ) {

    configure_port( LCD_CTRL_PORT, 0, LCD_CTRL_OUTPUT );
    configure_port( LCD_DATA_PORT, 0, LCD_DATA_OUTPUT );

    delay_factor( STARTUP_DELAY );
    lcd_configure( CONFIG_ARGS_8_BIT | CONFIG_ARGS_MULTI_LINE | CONFIG_ARGS_5X10_FONT );
    lcd_display_mode( DM_ARGS_NONE );
    lcd_clear( );
    lcd_display_mode( DM_ARGS_CURSOR_ON | DM_ARGS_CURSOR_BLINK | DM_ARGS_DISPLAY_ON );
    lcd_entry_mode( EM_ARGS_AUTO_INCREMENT );
    lcd_set_display_address( DA_ARGS_LINE1 );

}


int main ( void ) {

    uint8_t pos = 0;
    uint8_t counter = 0;

    lcd_init( );

    for ( ; ; ) {
        lcd_set_display_address( DA_ARGS_LINE1 );
        for ( pos = 0; pos < CHARS_PER_LINE; pos++ ) {
            lcd_put_char( counter++ );
        }
        lcd_set_display_address( DA_ARGS_LINE2 );
        for ( pos = 0; pos < CHARS_PER_LINE; pos++ ) {
            lcd_put_char( counter++ );
        }
        lcd_set_display_address( DA_ARGS_LINE1 );
        delay_factor( 0x3fff );
    }

}

